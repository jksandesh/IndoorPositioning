<?php
$db_name = "u972999677_login";
$mysql_user = "u972999677_rgstr";
$mysql_pass = "ishu123";
$server_name = "mysql.hostinger.in";
 
$con = mysqli_connect($server_name, $mysql_user, $mysql_pass, $db_name);
 
if(!$con){
    echo '{"message":"Unable to connect to the database."}';
}
 
$mac = $_POST["mac"];
$distance = $_POST["distance"];
$floor=$_POST["floor"];
 
//$name = "sdf";
//$password = "sdf";
//$email = "sdf@r54";
 
$sql = "UPDATE `entry` SET `Coordinates`='$distance',`Floor`='$floor' WHERE `Mac_ID`='$mac'";
if(!mysqli_query($con, $sql)){
    echo '{"message":"Unable to save the data to the database."}';
}
 
?>