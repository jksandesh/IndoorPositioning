package xyz.ishwarbhat.wifi;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;
import java.util.Random;

/**
 * Created by Ishu on 28-09-2016.
 */

public class background_task extends Service{


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
    }



    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
            repeat();
        return START_STICKY;
    }

    public void repeat()
    {
        new CountDownTimer(5000, 1000) {
            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                Register r = new Register();
                MainActivity ma = new MainActivity();
                String coordinate=ma.sendcordinates();
                WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo info = wifiManager.getConnectionInfo();
                String address = info.getMacAddress();
                r.execute(address, ""+coordinate,"1");
                repeat();
            }
        }.start();
    }
@Override
public void onDestroy()
{

}

}