package xyz.ishwarbhat.wifi;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import java.util.List;

public class MainActivity extends AppCompatActivity{
    public TextView tv2;
    public WifiManager wifiManager;
    wifireceiver wr;
    String result="Results:\n";
    String[] ssid_list=new String[3];
    double[] dst=new double[3];
    int[] rssi=new int[20];
    String address;
    public static String coordinates;
    boolean st=false;
    public String f;
    String R11="Ishueeta";
    String R12="EtaIshu";
    String R13="AndroidAP1";
    String R21="";
    String R22="";
    String R23="";
    String R31="";
    String R32="";
    String R33="";
    double[] avg_dst=new double[3];
    int c=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv2=(TextView)findViewById(R.id.textView2);
        wifiManager=(WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        address = info.getMacAddress();
        startService(new Intent(this,background_task.class));
        wr= new wifireceiver();
        registerReceiver(wr,new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        wifiManager.startScan();
        startscan();
    }



    public double calculate(float f,float r)
    {
        return Math.pow(10.0d, ((27.55d - (Math.log10(f) * 20.0d)) + Math.abs(r)) / 20.0d);
    }

    //Broadcost Reciever
    class wifireceiver extends BroadcastReceiver
    {

        @Override
        public void onReceive(Context context, Intent intent)
        {
            List<ScanResult> list=wifiManager.getScanResults();
            if(st==false)
            {
                int c=0;
                for(ScanResult i:list)
                {
                    if(i.SSID.equals(R11))
                    {ssid_list[0]=i.SSID;
                        rssi[0]=i.level;
                    }
                    else if(i.SSID.equals(R12))
                    {ssid_list[1]=i.SSID;
                        rssi[1]=i.level;
                    }
                    else if(i.SSID.equals(R13))
                    {ssid_list[2]=i.SSID;
                        rssi[2]=i.level;
                    }

                }

                st=true;

            }
            else if(st==true)
            {
                for(ScanResult i:list)
                {
                    if(i.SSID.equals(R11))
                    {
                        dst[0]=calculate(i.frequency,i.level);
                    }
                    else if(i.SSID.equals(R12))
                    {
                        dst[1]=calculate(i.frequency,i.level);
                    }
                    else if(i.SSID.equals(R13))
                    {
                        dst[2]=calculate(i.frequency,i.level);
                    }
                }

            }

        }
    }

    public void startscan() {

        new CountDownTimer(6000, 1000) {
            @Override
            public void onTick(long l) {
                wr = new wifireceiver();
                registerReceiver(wr, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
                wifiManager.startScan();
                for (int i = 0; i < 3; i++) {
                    avg_dst[i] = avg_dst[i] + dst[i];
                }
                c++;
            }

            public double range(double distr, double rang) {
                if (distr < 1)
                    return distr + 1;
                else if (distr > rang)
                    return rang - 1;
                else
                    return distr;

            }


            @Override
            public void onFinish() {
                if (ssid_list[0].equals(R11) || ssid_list[0].equals(R12) || ssid_list[0].equals(R13)) {
                    double t1 = 0, t2 = 0, t3 = 0;
                    t1 = range(avg_dst[0] / c, 2.23);
                    t2 = range(avg_dst[1] / c, 2.23);
                    t3 = range(avg_dst[2] / c, 2.23);
                    coordinates = Coordinates.calculate_cordinates(t1, t2, t3);
                    tv2.setText(coordinates);
                }

                for (int i = 0; i < 3; i++) {
                    result = result + ssid_list[i] + " -> " + (avg_dst[i] / c) + "\n";
                    avg_dst[i] = 0;
                }
                c = 0;
                st = false;
                startscan();
            }
        }.start();
    }
    public String sendcordinates()
    {
        return coordinates;
    }


    @Override
    public void onBackPressed() {

    }

    @Override
    public void onDestroy()
    {
        Register r = new Register();
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = wifiManager.getConnectionInfo();
        String address = info.getMacAddress();
        r.execute(address, "out of coverage","");
        super.onDestroy();
    }
}
