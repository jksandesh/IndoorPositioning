package xyz.ishwarbhat.wifi;

/**
 * Created by Ishu on 29-09-2016.
 */

public class Coordinates {

    public static String calculate_cordinates(double r1,double r2,double r3)
    {
        String first,second,third;

        double d1=2,d2=1;
        double x=((d1*d1)+(r1*r1)-(r2*r2))/(2*d1);
        double y=((d2*d2)+(r1*r1)-(r3*r3))/(2*d2);
        first=(""+x).substring(0,5);
        second=(""+y).substring(0,5);
        return "x:"+first+" y:"+second;
    }
}
