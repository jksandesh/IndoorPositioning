 <?php
$db_name = "u972999677_login";
$mysql_user = "u972999677_rgstr";
$mysql_pass = "ishu123";
$server_name = "mysql.hostinger.in";
 
$con = mysqli_connect($server_name, $mysql_user, $mysql_pass, $db_name);

		$sql="SELECT  * FROM  `entry`;";
		
		$result = mysqli_query($con,$sql);
		
	$response=array();

 while($row=mysqli_fetch_array($result))
{
array_push($response,array("name"=>$row[0],"floor"=>$row[3],"cordinate"=>$row[2]));
}
echo json_encode(array("server_response"=>$response));
mysqli_close($con);
?>